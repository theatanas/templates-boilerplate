;define(["jquery", "owl", "waypoints"], 
	function($, owl, waypoints){

	$(document).ready(function(){
		// Assign all vars
		var body = $("body");

	});
});